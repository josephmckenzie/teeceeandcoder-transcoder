'use strict';

var AWS = require('aws-sdk');
var firebase = require('firebase');

// save the URL to firebase
firebase.initializeApp({
 
    projectId: process.env.PROJECT_ID,
    clientEmail: process.env.CLIENT_EMAIL,
    "private_key": process.env.PRIVATE_KEY,
 
  databaseURL:  process.env.DATABASE_URL
});

exports.handler = function(event, context, callback){
    context.callbackWaitsForEmptyEventLoop = false;

    var key = event.Records[0].s3.object.key;
    var bucket = event.Records[0].s3.bucket.name;
console.log(key + "Key is ");
console.log(bucket, "bucket");
    var regionIdentifier = process.env.BUCKET_REGION === 'us-east-1' ? 's3' : 's3-' + process.env.BUCKET_REGION;
console.log(regionIdentifier,"regionIdentifier");
    var videoUrl = process.env.S3 + '/' + key;
console.log(videoUrl,"videoUrl")
    // construct S3 URL based on bucket and key
    // the input file may have spaces so replace them with '+'
    var sourceKey = decodeURIComponent(key.replace(/\+/g, ' '));
console.log(sourceKey,"sourceKey");
    // get the unique video key (the folder name)
    var uniqueVideoKey = sourceKey.split('/')[0];
    var multifilename =sourceKey.split('/')[1];
 console.log(multifilename,"multifilename");
   console.log(uniqueVideoKey,"uniqueVideoKey");
console.log(uniqueVideoKey); 
   var database = firebase.database().ref();
 
    // update the unique entry for this video in firebase
    database.child('videos').child(uniqueVideoKey).set({
        transcoding: false,
        source: videoUrl
    })
    .then(function(){
        callback(null, 'Added URL' + videoUrl);
    })
    .catch(function(err) {
        callback(err);
    });
};
